
public @interface Test {

}
