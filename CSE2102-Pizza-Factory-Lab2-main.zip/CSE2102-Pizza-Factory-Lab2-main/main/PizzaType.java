package main;

public enum PizzaType {
    CHEESE,
    GREEK,
    PEPPERONI,
    GLUTEN_FREE
}